PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "_prisma_migrations" (
    "id"                    TEXT PRIMARY KEY NOT NULL,
    "checksum"              TEXT NOT NULL,
    "finished_at"           DATETIME,
    "migration_name"        TEXT NOT NULL,
    "logs"                  TEXT,
    "rolled_back_at"        DATETIME,
    "started_at"            DATETIME NOT NULL DEFAULT current_timestamp,
    "applied_steps_count"   INTEGER UNSIGNED NOT NULL DEFAULT 0
);
INSERT INTO _prisma_migrations VALUES('5202d4ba-668d-4402-a0ee-89eb21f5a6b7','07504639c4720c6a4f163c9b6a6648226bda144c6ecd39845eee16b73d03ff0d',1755776073295,'20250821092140_add_invoice_system',NULL,NULL,1755776073292,1);
CREATE TABLE IF NOT EXISTS "users" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "email" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "role" TEXT NOT NULL DEFAULT 'USER',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO users VALUES('cmelbwjx20000a1sj4srxcys0','admin@aprepair.com','System Administrator','hashed_password_here','ADMIN',1755776347095,1755776347095);
INSERT INTO users VALUES('cmelbwjx70001a1sj1mdqthnj','tech@aprepair.com','John Technician','hashed_password_here','TECHNICIAN',1755776347099,1755776347099);
CREATE TABLE IF NOT EXISTS "customers" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "email" TEXT,
    "phone" TEXT NOT NULL,
    "address" TEXT,
    "company" TEXT,
    "taxId" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "createdBy" TEXT NOT NULL,
    CONSTRAINT "customers_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES "users" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO customers VALUES('cmelc0b5s0003a1wnlh8fttp7','บริษัท เอ็มไพร์ มายนิ่ง จำกัด','empire@example.com','0812345678','123 Mining Street, Bangkok 10110','Empire Mining Co., Ltd.','0123456789012',1755776522368,1755776522368,'cmelbwjx20000a1sj4srxcys0');
INSERT INTO customers VALUES('cmelc0b5u0005a1wn23h2fiw7','คุณสมชาย ใจดี','somchai@example.com','0898765432','456 Repair Road, Chiang Mai 50200',NULL,NULL,1755776522371,1755776522371,'cmelbwjx20000a1sj4srxcys0');
INSERT INTO customers VALUES('cmelc0b5v0007a1wnpfq1gzfr','คุณคริปโต ฟาร์ม','crypto@example.com','0834567890','789 Crypto Lane, Phuket 83000','Crypto Farm Ltd.','0987654321098',1755776522371,1755776522371,'cmelbwjx20000a1sj4srxcys0');
INSERT INTO customers VALUES('cmelkftnp0001a1p6lsasiv71','บริษัท คริปโต ฟาร์ม ใหม่ จำกัด','newcrypto@example.com','081-234-5678','123 ถนนคริปโต แขวงดิจิทัล เขตเทคโนโลยี กรุงเทพฯ 10400','คริปโต ฟาร์ม ใหม่','0123456789012',1755790683103,1755790683103,'cmelbwjx20000a1sj4srxcys0');
CREATE TABLE IF NOT EXISTS "technicians" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "email" TEXT,
    "phone" TEXT NOT NULL,
    "speciality" TEXT,
    "hourlyRate" REAL,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "createdBy" TEXT NOT NULL,
    CONSTRAINT "technicians_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES "users" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO technicians VALUES('cmelc0b5x0009a1wn54etzqay','ช่างสมชาย','tech1@aprepair.com','0811111111','POWER_SUPPLY',500.0,1,1755776522373,1755776522373,'cmelbwjx20000a1sj4srxcys0');
INSERT INTO technicians VALUES('cmelc0b5y000ba1wnifr1h64g','ช่างสมหญิง','tech2@aprepair.com','0822222222','FAN_COOLING',400.0,1,1755776522375,1755776522375,'cmelbwjx20000a1sj4srxcys0');
INSERT INTO technicians VALUES('cmelkfzxm0003a1p629gwyh1v','ช่างสมชาย ใจดี','somchai@example.com','082-345-6789',NULL,800.0,1,1755790691243,1755790691243,'cmelbwjx20000a1sj4srxcys0');
CREATE TABLE IF NOT EXISTS "miner_models" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "brand" TEXT NOT NULL,
    "model" TEXT NOT NULL,
    "series" TEXT,
    "hashRate" TEXT,
    "power" TEXT,
    "description" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO miner_models VALUES('bitmain-s19-xp','Bitmain','Antminer S19 XP',NULL,'140 TH/s','3010W','High-performance Bitcoin miner',1,1755776522376,1755776522376);
INSERT INTO miner_models VALUES('bitmain-s19j-pro','Bitmain','Antminer S19j Pro',NULL,'104 TH/s','3054W','Professional Bitcoin miner',1,1755776522376,1755776522376);
INSERT INTO miner_models VALUES('microbt-whatsminer-m50','MicroBT','WhatsMiner M50',NULL,'126 TH/s','3276W','Efficient Bitcoin miner',1,1755776522377,1755776522377);
CREATE TABLE IF NOT EXISTS "work_orders" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "orderNumber" TEXT NOT NULL,
    "customerId" TEXT NOT NULL,
    "technicianId" TEXT,
    "minerModelId" TEXT,
    "serialNumber" TEXT,
    "issue" TEXT NOT NULL,
    "diagnosis" TEXT,
    "solution" TEXT,
    "status" TEXT NOT NULL DEFAULT 'PENDING',
    "priority" TEXT NOT NULL DEFAULT 'MEDIUM',
    "estimatedCost" REAL,
    "actualCost" REAL,
    "startDate" DATETIME,
    "completedDate" DATETIME,
    "notes" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "createdBy" TEXT NOT NULL,
    CONSTRAINT "work_orders_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "customers" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "work_orders_technicianId_fkey" FOREIGN KEY ("technicianId") REFERENCES "technicians" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "work_orders_minerModelId_fkey" FOREIGN KEY ("minerModelId") REFERENCES "miner_models" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "work_orders_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES "users" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO work_orders VALUES('cmelc0b62000da1wnqkj052eo','WO-2025-0821-001','cmelc0b5s0003a1wnlh8fttp7','cmelc0b5x0009a1wn54etzqay',NULL,NULL,'ซ่อม Power Supply ที่เสียหาย',NULL,NULL,'IN_PROGRESS','HIGH',4000.0,3500.0,NULL,NULL,NULL,1755776522378,1755776522378,'cmelbwjx20000a1sj4srxcys0');
INSERT INTO work_orders VALUES('cmelc0b63000fa1wnx551s7dy','WO-2025-0821-002','cmelc0b5u0005a1wn23h2fiw7','cmelc0b5y000ba1wnifr1h64g',NULL,NULL,'เปลี่ยน Fan ที่เสียหาย',NULL,NULL,'COMPLETED','MEDIUM',1500.0,1605.0,NULL,NULL,NULL,1755776522379,1755776522379,'cmelbwjx20000a1sj4srxcys0');
INSERT INTO work_orders VALUES('cmelc0b63000ha1wnrh4qs6k2','250821005','cmelc0b5v0007a1wnpfq1gzfr','cmelc0b5x0009a1wn54etzqay',NULL,NULL,'ทำความสะอาดระบบระบายความร้อน',NULL,NULL,'COMPLETED','LOW',1100.0,1177.0,NULL,NULL,NULL,1755776522380,1755776522380,'cmelbwjx20000a1sj4srxcys0');
INSERT INTO work_orders VALUES('cmelkh12q0009a1p6fgywfut2','WO-2025-0821-004','cmelkftnp0001a1p6lsasiv71','cmelkfzxm0003a1p629gwyh1v','microbt-whatsminer-m50','WM50-2025-001','เครื่องขุดไม่ทำงาน ไฟไม่ติด ต้องตรวจสอบ power supply และ mainboard',NULL,NULL,'COMPLETED','HIGH',2500.0,2800.0,NULL,1755790757408,NULL,1755790739377,1755790757409,'cmelbwjx20000a1sj4srxcys0');
CREATE TABLE IF NOT EXISTS "invoices" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "invoiceNumber" TEXT NOT NULL,
    "customerId" TEXT NOT NULL,
    "workOrderId" TEXT,
    "status" TEXT NOT NULL DEFAULT 'DRAFT',
    "issueDate" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "dueDate" DATETIME NOT NULL,
    "subtotal" REAL NOT NULL DEFAULT 0,
    "taxAmount" REAL NOT NULL DEFAULT 0,
    "discountAmount" REAL NOT NULL DEFAULT 0,
    "totalAmount" REAL NOT NULL DEFAULT 0,
    "paidAmount" REAL NOT NULL DEFAULT 0,
    "balanceAmount" REAL NOT NULL DEFAULT 0,
    "notes" TEXT,
    "terms" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "createdBy" TEXT NOT NULL,
    CONSTRAINT "invoices_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "customers" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "invoices_workOrderId_fkey" FOREIGN KEY ("workOrderId") REFERENCES "work_orders" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "invoices_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES "users" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO invoices VALUES('cmelc0b65000ja1wnnwacbaix','INV250821001','cmelc0b5s0003a1wnlh8fttp7','cmelc0b62000da1wnqkj052eo','PARTIAL',1755734400000,1758412800000,4000.0,280.0,0.0,4280.0,2000.0,2280.0,'ซ่อม Power Supply ที่เสียหาย','ชำระภายใน 30 วัน',1755776522381,1755776522381,'cmelbwjx20000a1sj4srxcys0');
INSERT INTO invoices VALUES('cmelc0b66000la1wnsaepa805','INV250821002','cmelc0b5u0005a1wn23h2fiw7','cmelc0b63000fa1wnx551s7dy','PAID',1755734400000,1758412800000,1500.0,105.0,0.0,1605.0,1605.0,0.0,'เปลี่ยน Fan ที่เสียหาย','ชำระภายใน 30 วัน',1755776522383,1755776522383,'cmelbwjx20000a1sj4srxcys0');
INSERT INTO invoices VALUES('cmelc0b67000na1wnhdymrpvd','INV250821003','cmelc0b5v0007a1wnpfq1gzfr','cmelc0b63000ha1wnrh4qs6k2','PAID',1755734400000,1758412800000,1100.0,77.0,0.0,1177.0,1177.0,0.0,'ทำความสะอาดระบบระบายความร้อน','ชำระภายใน 30 วัน',1755776522384,1755776522384,'cmelbwjx20000a1sj4srxcys0');
INSERT INTO invoices VALUES('cmelkme9j000ba1p6b7cuw3dn','INV250821004','cmelkftnp0001a1p6lsasiv71','cmelkh12q0009a1p6fgywfut2','PAID',1755791400000,1758469800000,2800.0,196.0,0.0,2996.0,2996.0,0.0,'ใบแจ้งหนี้สำหรับงานซ่อมเครื่องขุด เปลี่ยน power supply ใหม่',NULL,1755790989751,1755791072901,'cmelbwjx20000a1sj4srxcys0');
CREATE TABLE IF NOT EXISTS "invoice_items" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "invoiceId" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "quantity" REAL NOT NULL DEFAULT 1,
    "unitPrice" REAL NOT NULL,
    "totalPrice" REAL NOT NULL,
    "type" TEXT NOT NULL DEFAULT 'SERVICE',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "invoice_items_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES "invoices" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO invoice_items VALUES('cmelc0b68000pa1wnp811zrpm','cmelc0b65000ja1wnnwacbaix','ซ่อม Power Supply',1.0,2500.0,2500.0,'SERVICE',1755776522384,1755776522384);
INSERT INTO invoice_items VALUES('cmelc0b69000ra1wnv8g4svl3','cmelc0b65000ja1wnnwacbaix','อะไหล่ Power Supply Unit',1.0,1500.0,1500.0,'PARTS',1755776522385,1755776522385);
INSERT INTO invoice_items VALUES('cmelc0b69000ta1wncg6zk8xk','cmelc0b66000la1wnsaepa805','ตรวจสอบและซ่อม Fan',1.0,800.0,800.0,'SERVICE',1755776522386,1755776522386);
INSERT INTO invoice_items VALUES('cmelc0b69000va1wn41e1dsjg','cmelc0b66000la1wnsaepa805','Fan ใหม่',2.0,300.0,600.0,'PARTS',1755776522386,1755776522386);
INSERT INTO invoice_items VALUES('cmelc0b6a000xa1wnt3irlntg','cmelc0b67000na1wnhdymrpvd','ทำความสะอาดระบบระบายความร้อน',1.0,800.0,800.0,'SERVICE',1755776522386,1755776522386);
INSERT INTO invoice_items VALUES('cmelc0b6b000za1wnlwo6y2ac','cmelc0b67000na1wnhdymrpvd','สารทำความสะอาดและอุปกรณ์',1.0,300.0,300.0,'PARTS',1755776522387,1755776522387);
INSERT INTO invoice_items VALUES('cmelkme9j000ca1p65khjh7l1','cmelkme9j000ba1p6b7cuw3dn','ซ่อมเครื่องขุด WhatsMiner M50',1.0,2800.0,2800.0,'SERVICE',1755790989751,1755790989751);
CREATE TABLE IF NOT EXISTS "payments" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "invoiceId" TEXT NOT NULL,
    "amount" REAL NOT NULL,
    "paymentDate" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "paymentMethod" TEXT NOT NULL,
    "reference" TEXT,
    "notes" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "payments_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES "invoices" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO payments VALUES('cmelc0b6b0011a1wn5tb06qbx','cmelc0b65000ja1wnnwacbaix',2000.0,1755820800000,'BANK_TRANSFER','TRX001','ชำระบางส่วน',1755776522388,1755776522388);
INSERT INTO payments VALUES('cmelc0b6c0013a1wne4v1tbyl','cmelc0b66000la1wnsaepa805',802.0,1755734400000,'BANK_TRANSFER','TRX547957','ชำระเงินงวดที่ 1 (50%)',1755776522388,1755776522388);
INSERT INTO payments VALUES('cmelc0b6d0015a1wnaoksowhg','cmelc0b66000la1wnsaepa805',803.0,1755734400000,'CASH',NULL,'ชำระเงินงวดสุดท้าย (ครบถ้วน)',1755776522389,1755776522389);
INSERT INTO payments VALUES('cmelc0b6e0017a1wnin9hzhsr','cmelc0b67000na1wnhdymrpvd',1177.0,1755820800000,'CREDIT_CARD','CC123456','ชำระครบถ้วน',1755776522390,1755776522390);
INSERT INTO payments VALUES('cmelko6f5000ea1p6j0sz6m0j','cmelkme9j000ba1p6b7cuw3dn',2996.0,1755792000000,'BANK_TRANSFER','TRX-2025-0821-001','ชำระเงินเต็มจำนวนผ่านโอนเงิน',1755791072897,1755791072897);
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");
CREATE UNIQUE INDEX "customers_email_key" ON "customers"("email");
CREATE UNIQUE INDEX "technicians_email_key" ON "technicians"("email");
CREATE UNIQUE INDEX "work_orders_orderNumber_key" ON "work_orders"("orderNumber");
CREATE UNIQUE INDEX "invoices_invoiceNumber_key" ON "invoices"("invoiceNumber");
COMMIT;
